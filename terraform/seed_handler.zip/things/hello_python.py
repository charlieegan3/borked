import json

def lambda_handler(event, context):
    print("Hello world")
    return json.dumps({'key1': val1, 'key2': val2})
